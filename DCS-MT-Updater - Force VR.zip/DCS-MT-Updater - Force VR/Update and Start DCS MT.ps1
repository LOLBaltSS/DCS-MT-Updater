﻿$OpenBetaPath = Get-ItemPropertyValue -Path 'HKLM:SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\DCS World OpenBeta_is1\' -Name InstallLocation

#Check for Updates
Start-Process -FilePath "$OpenBetaPath\bin\DCS_updater.exe" -ArgumentList "update" -Wait

#Checks to see if DCS_Updater re-launched (usually after an update to the updater itself)
Start-Sleep 5
 
While(Get-Process -Name "DCS_updater"){
Start-Sleep 1
}

#Start DCS after update completed
Start-Process -FilePath "$OpenBetaPath\bin-mt\DCS.exe" -ArgumentList "--force_enable_VR"